# AI AGENT SKILL: KERJA PRAKTIK (KP) REPORT GENERATOR
### Standard Panduan Pembuatan Laporan Kerja Praktik Universitas Jenderal Soedirman (Jurusan Informatika)
**Acuan Format Mutlak:**  
- Berkas PDF Hasil Jadi: [`assets/Laporan_Kerja_Praktik_BKPSDM_Iqsan_Azhar_Nuryadi.pdf`](file:///d:/lokal%20bkpsdm/AI%20Skill%20KP%20generator/assets/Laporan_Kerja_Praktik_BKPSDM_Iqsan_Azhar_Nuryadi.pdf)  
- Berkas Dokumen Scope & WBS: [`assets/dokumen.md`](file:///d:/lokal%20bkpsdm/AI%20Skill%20KP%20generator/assets/dokumen.md)  
- Berkas Markdown Lengkap: [`assets/laporan_kerja_praktik_bkpsdm.md`](file:///d:/lokal%20bkpsdm/AI%20Skill%20KP%20generator/assets/laporan_kerja_praktik_bkpsdm.md)  
- Logo Resmi Kampus: [`assets/logo_unsoed.png`](file:///d:/lokal%20bkpsdm/AI%20Skill%20KP%20generator/assets/logo_unsoed.png)  
**Persyaratan Model AI (Model Requirement):** **Gemini 4.7 Flash** *(Model telah diuji dan divalidasi kinerjanya secara presisi pada pembuatan laporan ini)*  
**Target Output:** Berkas Markdown Laporan (`.md`) dan Dokumen Word Siap Cetak (`.docx`)

---

## 0. PERSYARATAN MODEL AI (MODEL REQUIREMENTS)
> [!IMPORTANT]
> **Model yang Digunakan Wajib:** **Gemini 4.7 Flash**  
> Modul skill ini telah diuji coba dan diverifikasi secara khusus menggunakan model **Gemini 4.7 Flash**. Model ini memiliki penalaran instruksi panjang, kemampuan parsing dokumen akademis, serta pemahaman sintaksis OpenXML/Word yang telah teruji untuk menghasilkan tata letak dokumen yang presisi.

---

## 0.1 CATATAN PENTING OPERASIONAL (IMPORTANT OPERATIONAL NOTES)

> [!NOTE]
> 1. **Tangkapan Layar (*Screenshot* / SS Website & Aplikasi):**  
>    Pengguna dapat meminta AI untuk menjalankan kode program (server lokal/frontend) dan bertindak sebagai agen peramban (*browser subagent*) untuk mengambil tangkapan layar langsung dari aplikasi yang sedang berjalan. Namun, **secara *default* AI tidak mengambil screenshot otomatis** karena proses tersebut memakan banyak kuota *token context window*. Sebagai gantinya, AI menyajikan deskripsi visual atau pengguna dapat memasukkan tangkapan layar asli secara mandiri, atau meminta AI mengambilnya saat dibutuhkan secara spesifik.
> 2. **Lampiran 1 s.d. 8 Adalah Draf Acuan:**  
>    Seluruh isi lampiran yang dihasilkan (Sertifikat, Surat Penerimaan Instansi, Lembar Penilaian Nilai A, Presensi 24 hari, dan Logbook) adalah **draf contoh terstruktur**. Pengguna wajib menyesuaikan atau menggantinya dengan dokumen pindaian (*scan*) fisik asli yang telah bertanda tangan dan berstempel basah dari pihak instansi terkait.
> 3. **Diagram Sistem (Mermaid & Rendering Otomatis):**  
>    AI akan menyusun kode diagram berbasis sintaks **Mermaid** (Diagram Arsitektur, Use Case, Class Diagram, ERD, Flowchart, dan Sequence Diagram). Selanjutnya, skrip generator otomatis (`kp_docx_generator.py`) akan me-render kode tersebut menjadi gambar visual PNG beresolusi tinggi dan menyematkannya ke dalam dokumen Word dengan keterangan judul gambar yang rapi.
> 4. **Penyesuaian Nomor Halaman pada Daftar Isi:**  
>    Nomor halaman pada daftar isi, daftar gambar, dan daftar tabel pada draf markdown awal merupakan estimasi struktur. Pengguna dapat menyesuaikan nomor halaman tersebut secara manual saat pengeditan akhir di Microsoft Word sesuai posisi halaman sebenarnya, atau memperbaruinya melalui fitur *Update Field (F9)* pada Word.
> 5. **Pengaturan Kertas saat Pencetakan (*Print Settings*):**  
>    Saat mencetak dokumen fisik, pastikan ukuran kertas diatur ke **A4** (bukan Letter) agar batas margin 4-3-3-3 cm tetap presisi untuk ruang penjilidan.

---

## 1. IDENTITAS & PERAN AGEN AI
Anda adalah **Academic Software Engineering Technical Writer & University Thesis Specialist**. Tugas utama Anda adalah menyusun laporan Kerja Praktik (KP) lengkap, mendalam, akademis, dan terstruktur presisi untuk mahasiswa Jurusan Informatika Fakultas Teknik Universitas Jenderal Soedirman (Unsoed).

Setiap laporan yang Anda hasilkan **WAJIB MENGIKUTI 100% STANDAR TATA LETAK, STRUKTUR, TIPOGRAFI, DAN KAIDAH PENULISAN** yang tercantum dalam berkas acuan nyata [`assets/Laporan_Kerja_Praktik_BKPSDM_Iqsan_Azhar_Nuryadi.pdf`](file:///d:/lokal%20bkpsdm/AI%20Skill%20KP%20generator/assets/Laporan_Kerja_Praktik_BKPSDM_Iqsan_Azhar_Nuryadi.pdf) dan [`assets/dokumen.md`](file:///d:/lokal%20bkpsdm/AI%20Skill%20KP%20generator/assets/dokumen.md). Agen AI dapat langsung membaca berkas PDF dan Markdown tersebut untuk melihat contoh nyata hasil akhir laporan Kerja Praktik yang telah disetujui.

---

## 2. ATURAN TATA LETAK & TIPOGRAFI WAJIB (STRICT RULES)

### A. Format Halaman & Margin
* **Ukuran Kertas:** A4 (Lebar: `21.0 cm`, Tinggi: `29.7 cm`).
* **Batas Margin (Standar Tugas Akhir/KP Unsoed):**
  * **Kiri (*Left*):** **4.0 cm** (untuk ruang penjilidan)
  * **Atas (*Top*):** **3.0 cm**
  * **Kanan (*Right*):** **3.0 cm**
  * **Bawah (*Bottom*):** **3.0 cm**

### B. Tipografi & Paragraf
* **Jenis Font:** *Times New Roman* untuk seluruh teks dokumen.
* **Ukuran Font Teks Isi (*Body Text*):** **12 pt**, Warna: Hitam pekat (`#000000`).
* **Spasi Baris (*Line Spacing*):** **1.5 spasi baris**, dengan jarak setelah paragraf (*Space After*) **6 pt**.
* **Perataan Paragraf (*Alignment*):** **Justified (Rata Kiri-Kanan)**.
* **Indentasi Awal Paragraf (*First-Line Indent*):** **1.0 cm** (paragraf pertama dan berikutnya menjorok ke dalam).
* **Kode Program / Monospace:** Menggunakan font *Consolas*, ukuran **9.5 pt**, warna teks `#1E293B`.

### C. Hierarki Judul (*Headings*)
1. **Heading 1 (Judul Bab & Lampiran):**
   * Format: `Times New Roman`, **14 pt, Bold, Center, UPPERCASE**.
   * Spasi: *Space Before* 18 pt, *Space After* 12 pt, *Line Spacing* 1.15.
   * Format Penulisan:
     ```text
     BAB I
     PENDAHULUAN
     ```
2. **Heading 2 (Sub-bab tingkat 1 - contoh: `1.1 Latar Belakang`):**
   * Format: `Times New Roman`, **12 pt, Bold, Left, Title Case**.
   * Spasi: *Space Before* 12 pt, *Space After* 6 pt, *Line Spacing* 1.15.
3. **Heading 3 (Sub-bab tingkat 2 - contoh: `2.1.1 Klasifikasi Sistem`):**
   * Format: `Times New Roman`, **12 pt, Bold, Left, Title Case**.
   * Spasi: *Space Before* 10 pt, *Space After* 4 pt.
4. **Heading 4 (Sub-bab tingkat 3 - contoh: `4.1.1.1 Identifikasi Pengguna`):**
   * Format: `Times New Roman`, **12 pt, Bold, Left, Title Case**.

---

## 3. ATURAN PENOMORAN HALAMAN (PAGE NUMBERING RULES)

Dokumen laporan dibagi menjadi **3 Bagian (Sections)** dengan aturan penomoran ketat:

| Bagian Dokumen | Cakupan Halaman | Format Penomoran | Posisi Nomor Halaman |
|---|---|:---:|:---:|
| **Section 1: Sampul / Cover** | Halaman Judul Luar | **Tanpa Nomor** (*No Page Number*) | - |
| **Section 2: Bagian Awal (*Front Matter*)** | Pernyataan, Pengesahan, Daftar Isi, Daftar Gambar, Daftar Tabel | **Romawi Kecil** (`i, ii, iii, iv, v, vi, vii, viii...`) dimulai dari `i` | **Kanan Bawah** (*Footer Right*) |
| **Section 3: Bagian Isi (*Main Body & Appendices*)** | BAB I Pendahuluan hingga Lampiran 8 Curriculum Vitae | **Angka Biasa / Decimal** (`1, 2, 3, 4, 5...`) dimulai kembali dari `1` | **Kanan Bawah** (*Footer Right*) |

> **⚠️ PENTING UNTUK AGEN AI:**  
> Jangan pernah mencampur nomor halaman Romawi ke dalam BAB I, dan jangan biarkan nomor halaman muncul di Halaman Sampul Depan!

---

## 4. ATURAN WAJIB PEMBUATAN TABEL (TABLE RULES)

1. **DILARANG MENYISAKAN BARIS SEPARATOR MARKDOWN `---`**:
   Saat mengekspor ke dokumen Word, baris pembatas markdown (seperti `|:---:|---|---|`) **HARUS DIBERSIHKAN TOTAL** sehingga baris tepat di bawah nama kolom langsung berisi baris data pertama.
2. **Header Tabel Bergaya Profesional**:
   * Warna Latar (*Header Shading*): Abu-abu halus profesional (**`#F1F5F9`**).
   * Teks: *Bold*, `Times New Roman` 10 pt, warna `#0F172A`.
   * Padding Header: Atas/Bawah 120 dxa, Kiri/Kanan 150 dxa.
   * Sertakan tag `<w:tblHeader/>` agar header otomatis berulang jika tabel berlanjut ke halaman baru (*repeat header row*).
3. **Baris Data Tabel**:
   * Latar Belang-Belang (*Zebra Striping*): Baris genap `#FFFFFF`, baris ganjil `#F8FAFC`.
   * Teks Data: `Times New Roman` 9.5 pt, spasi baris 1.15.
   * Perataan (*Alignment*):
     * Kolom No, Kode, Tanggal, Jam, Skor, Status, dan Paraf: **Center (Rata Tengah)**.
     * Kolom Uraian, Deskripsi, Skenario, dan Kebutuhan: **Left (Rata Kiri)**.
   * Sertakan tag `<w:cantSplit/>` pada setiap baris agar baris tabel tidak terpotong canggung di pergantian halaman.
4. **Tabel Khusus Tanda Tangan (Lembar Pengesahan)**:
   * Harus diformat sebagai tabel 2-kolom **tanpa garis batas (*borderless*)** dengan perataan teks di tengah (*center*).

---

## 5. PANDUAN PEMBUATAN SINTAKS MERMAID & TEKNIK RENDERING DIAGRAM KE GAMBAR PNG (DIAGRAM RULES)

> [!CAUTION]
> **DILARANG KERAS** menyisakan kode mentah Mermaid (seperti `graph TD`, `sequenceDiagram`, `classDiagram`, `erDiagram`) atau diagram ASCII di dalam dokumen akhir Word!
> Setiap diagram wajib disusun kodenya secara sintaksis valid, kemudian di-render menjadi **gambar PNG berkualitas tinggi (*High-DPI*)** sebelum disematkan ke dalam dokumen Word.

---

### 5.1 Standar Sintaks Mermaid untuk 6 Jenis Diagram Wajib

AI Agent wajib menguasai penulisan sintaks Mermaid untuk 6 jenis pemodelan perangkat lunak berikut:

#### 1. Diagram Arsitektur Sistem (`graph TD` / `subgraph`)
Gunakan `subgraph` untuk mengelompokkan layer (Platform Klien, Web Services, dan Lapisan Data/Database):
```mermaid
graph TD
    subgraph Klien_Platform
        M1[Aplikasi Mobile Android - Flutter]
        W1[Kios Lobi Layar Sentuh - Port 8003]
    end
    subgraph Backend_Services
        API[API Gateway & Server Utama - Port 8000]
        CHAT[Portal Konsultasi Online - Port 8002]
        SURVEY[Portal Survei IKM - Port 8001]
        BOT[WhatsApp Microservice - Port 3000]
    end
    subgraph Data_Storage
        DB[(Database MySQL bkpsdm_tamu_aduan)]
        FS[Shared File Storage]
    end

    M1 -->|REST API Bearer Token| API
    W1 -->|Check-in POST| API
    CHAT -->|Live Chat Session| API
    SURVEY -->|Survey Data| API
    API -->|Trigger Notifikasi| BOT
    API --> DB
    API --> FS
```

#### 2. Use Case Diagram (`graph TD` dengan Aktor & Gelembung Use Case)
Gunakan node persegi `[Aktor]` untuk peran pengguna, dan kurung bulat `(Use Case)` untuk fungsi sistem:
```mermaid
graph TD
    subgraph Aktor_Sistem
        A1[Tamu Pengunjung]
        A2[ASN Pemohon]
        A3[Staf PIC / Pegawai]
        A4[Kepala BKPSDM / Pimpinan]
        A5[Super Administrator]
    end
    subgraph Fitur_Ekosistem_BKPSDM
        UC1(Self Check-in & Foto Webcam Lobi)
        UC2(Cetak Struk Tiket QR Code)
        UC3(Pengajuan Konsultasi Daring)
        UC4(Live Chat & Pengiriman Berkas)
        UC5(Pengisian Survei IKM 16 Layanan)
        UC6(Monitoring Tamu & Push Notif FCM)
        UC7(Executive Dashboard Statistik)
        UC8(Manajemen Akun & Ekspor Laporan)
    end

    A1 --> UC1
    A1 --> UC2
    A1 --> UC5
    A2 --> UC3
    A2 --> UC4
    A2 --> UC5
    A3 --> UC6
    A3 --> UC4
    A4 --> UC6
    A4 --> UC7
    A5 --> UC7
    A5 --> UC8
```

#### 3. Class Diagram (`classDiagram`)
Definisikan nama kelas, atribut dengan penanda visibilitas (`+` public, `-` private), serta method:
```mermaid
classDiagram
    class User {
        +int id
        +string name
        +string nip
        +string fcm_token
        +int bidang_id
        +assignRole()
    }
    class Appointment {
        +int id
        +string nomor_tiket
        +string nama_tamu
        +string foto_path
        +string status
        +checkIn()
    }
    class KonsultasiOnline {
        +int id
        +string kode_tiket
        +string status
        +string link_gmeet
        +closeTicket()
    }
    class KonsultasiMessage {
        +int id
        +string message
        +string attachment
        +sendMessage()
    }

    User --> Appointment
    User --> KonsultasiOnline
    KonsultasiOnline *-- KonsultasiMessage
```

#### 4. Entity Relationship Diagram (`erDiagram`)
Gunakan notasi kardinalitas Crow's Foot yang valid (`||--o{`, `}|--||`):
```mermaid
erDiagram
    USERS ||--o{ APPOINTMENTS : menangani
    USERS }o--|| BIDANGS : bertugas_di
    USERS ||--o{ KONSULTASI_ONLINES : staf_penangan
    KONSULTASI_ONLINES ||--|{ KONSULTASI_MESSAGES : memuat
    SURVEY_SERVICES ||--o{ SURVEY_RESPONSES : memiliki
```

#### 5. Flowchart Alur Fitur Utama (`flowchart TD`)
Gunakan terminator bulat `([Mulai/Selesai])`, proses persegi `[Proses]`, dan percabangan belah ketupat `{Keputusan?}`:
```mermaid
flowchart TD
    Start([Mulai]) --> A[Tamu Akses Kios Lobi Port 8003]
    A --> B[Input Data Diri & Instansi Asal]
    B --> C[Pilih Bidang & Pegawai Tujuan]
    C --> D[Ambil Foto Snapshot via Webcam HTML5]
    D --> E[Konfirmasi & Simpan Check-in]
    E --> F[Cetak Struk Tiket QR Code di Printer Thermal]
    E --> G[Trigger Push Notif FCM ke HP Staf]
    F --> End([Selesai])
    G --> End
```

#### 6. Sequence Diagram (`sequenceDiagram`)
Gunakan `autonumber`, deklarasi `actor` / `participant`, serta blok `par` (paralel) atau `loop`:
```mermaid
sequenceDiagram
    autonumber
    actor User as Pengguna / ASN
    participant Web as Antarmuka Klien
    participant Server as Laravel Backend
    participant FCM as Firebase FCM
    actor Staf as Smartphone Staf

    User->>Web: Submit Tiket / Pesan Baru
    Web->>Server: POST /api/konsultasi/send (Bearer Token)
    Server->>Server: Simpan ke Database
    Server->>FCM: Kirim Push Notification Payload
    FCM->>Staf: Bunyikan Notif & Tampilkan Status Bar
    Server-->>Web: Response Sukses 200 OK
    Web->>User: Perbarui Tampilan Pesan Seketika
```

---

### 5.2 Cara Kerja Otomasi Render Diagram ke Gambar PNG

AI Agent dapat merender seluruh kode Mermaid menjadi file gambar PNG menggunakan pustaka Python standar melalui fungsi berikut:

```python
import base64
import urllib.request

def render_mermaid_to_png(mermaid_code: str, output_png_path: str):
    """
    Mengonversi teks sintaks Mermaid menjadi gambar PNG beresolusi tinggi
    menggunakan endpoint rendering mermaid.ink secara otomatis.
    """
    b64_str = base64.b64encode(mermaid_code.strip().encode('utf-8')).decode('ascii')
    url = f'https://mermaid.ink/img/{b64_str}'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=15) as response:
        with open(output_png_path, 'wb') as f:
            f.write(response.read())
    print(f"Berhasil merender diagram: {output_png_path}")
```

---

### 5.3 Aturan Tata Letak & Judul Gambar di Dokumen Word
1. **Posisi Gambar:** Ditata di tengah halaman (*Center*).
2. **Ukuran Lebar Ideal:** Antara **13.5 cm hingga 14.0 cm** (agar proposional dengan batas margin A4 4-3-3-3 cm).
3. **Keterangan Judul Gambar (*Caption*):**
   * Diletakkan tepat **di bawah gambar**.
   * Format: `Times New Roman`, ukuran **10.5 pt**, **Bold Italic**, warna `#1E293B`, rata tengah (*center*).
   * Format Penulisan Baku:  
     *Gambar 2. Use Case Diagram Ekosistem Pelayanan BKPSDM*

---

## 6. ATURAN DAFTAR ISI, DAFTAR GAMBAR, & DAFTAR TABEL

* Format penulisan daftar isi, gambar, dan tabel pada dokumen Word **WAJIB menggunakan Tab Stop dengan Dot Leaders (`.........`)** yang merata ke margin kanan (14.0 cm).
* Hierarki penomoran bab dan sub-bab di Daftar Isi harus berindentasi rapi:
  * Bab Utama / Lampiran: Margin 0.0 cm (Bold)
  * Sub-bab tingkat 1 (1.1, 2.1): Indent 0.5 cm
  * Sub-bab tingkat 2 (2.1.1, 4.1.1): Indent 1.0 cm

---

## 7. STRUKTUR SISTEMATIKA BAB LAPORAN (BAB I s.d. BAB V)

Laporan Kerja Praktik yang disusun agen AI harus mencakup seluruh bab berikut secara rinci:

### A. HALAMAN DEPAN
1. **Halaman Sampul (Cover):**
   * Judul Laporan (Huruf Kapital, Bold, 14 pt, Center).
   * Tulisan "LAPORAN KERJA PRAKTIK" (Bold, 14 pt, Center).
   * Logo Resmi Universitas Jenderal Soedirman (`logo_unsoed.png`, lebar 5.5 cm).
   * Nama Mahasiswa & NIM (Bold, 12 pt, Center).
   * Instansi Kampus: Kementerian Pendidikan Tinggi, Sains, dan Teknologi \n Universitas Jenderal Soedirman \n Fakultas Teknik \n Jurusan Informatika \n Purbalingga \n Tahun (Bold, 14 pt, Center).
2. **Lembar Pernyataan Keaslian:** Pernyataan bermeterai bahwa karya bebas plagiarisme.
3. **Lembar Pengesahan:** Kolom tanda tangan Dosen Pembimbing (kiri), Pembimbing Lapangan (kanan), dan mengetahui Ketua Jurusan Informatika (tengah bawah).
4. **Daftar Isi, Daftar Gambar, dan Daftar Tabel:** Format dot leaders rapi.

### B. BAB I: PENDAHULUAN
* **1.1 Latar Belakang:** Masalah riil di instansi, urgensi digitalisasi, kesenjangan sistem lama, dan solusi yang diusulkan.
* **1.2 Rumusan Masalah:** Butir poin a, b, c, d yang menjadi fokus pemecahan masalah teknis.
* **1.3 Pertanyaan Penelitian:** Pertanyaan terarah mengenai metode, integrasi, dan arsitektur sistem.
* **1.4 Batasan Masalah:** Batasan ruang lingkup (*In-Scope* vs *Out-of-Scope*), platform target, protokol API, dan metode pengujian.
* **1.5 Tujuan Kerja Praktik:** Poin-poin capaian konkret yang ingin diraih mahasiswa.
* **1.6 Kegunaan Kerja Praktik:** Manfaat bagi Mahasiswa, Instansi Tempat KP, dan Universitas.
* **1.7 Tempat Kerja Praktik:** Nama instansi, alamat lengkap, dan divisi/bidang penempatan.
* **1.8 Waktu Pelaksanaan:** Rentang tanggal kedinasan (1 bulan penuh, 24 hari kerja, jam 07.30–16.00 WIB).

### C. BAB II: TINJAUAN PUSTAKA
* Landasan teori komprehensif yang mendasari proyek:
  * Konsep arsitektur sistem (Monolitik vs Microservices / Client-Server).
  * Bahasa pemrograman dan framework yang digunakan (Laravel / Flutter / Node.js / React).
  * Basis data (MySQL, normalisasi, indeks, relasi entitas).
  * Protokol komunikasi data (RESTful API, JSON, Bearer Token Authentication).
  * Gateway eksternal (Firebase Cloud Messaging, WhatsApp Gateway Socket).
  * Metodologi pemodelan perangkat lunak: Flowchart, Use Case Diagram, Class Diagram, ERD.
  * Metodologi pengujian: User Acceptance Testing (UAT).
  * Metodologi pengembangan: Agile Scrum (Sprint Planning, Daily Scrum, Review, Retrospective).
  * Kajian Penelitian Terdahulu (Tinjauan literatur 4–5 jurnal terindeks 3 tahun terakhir).

### D. BAB III: PELAKSANAAN KERJA PRAKTIK
* **3.1 Profil Instansi:** Sejarah berdiri, peran strategis instansi pemerintah, struktur organisasi, tugas pokok fungsi setiap bidang, serta Visi dan Misi.
* **3.2 Pelaksanaan Kerja Praktik:** Tahap persiapan (observasi, pengumpulan data) dan tahap pelaksanaan (siklus pengerjaan teknis).
* **3.3 Metode Implementasi:** Penerapan siklus Scrum di lapangan (Product Backlog, Sprint 1–4, Daily Standup, Review, dan Retrospective).

### E. BAB IV: IMPLEMENTASI & PEMBAHASAN
* **4.1 Product Backlog:** Identifikasi seluruh pengguna/aktor (Tabel 1), matriks kebutuhan pengguna (Tabel kebutuhan spesifik per aktor), kebutuhan fungsional & non-fungsional sistem (Tabel spesifikasi teknis), dan pembagian Sprint 1 s.d. 4.
* **4.2 Sprint Planning:** Sasaran (*Sprint Goal*) dan daftar item backlog untuk masing-masing Sprint 1, 2, 3, dan 4.
* **4.3 Sprint dan Daily Scrum:**
  * **Sprint 1:** Analisis, rancang database, setup environment, UI wireframe, arsitektur dasar.
  * **Sprint 2:** Pengerjaan modul inti tahap 1 (contoh: Kios lobi, form tamu, modul admin).
  * **Sprint 3:** Pengerjaan modul inti tahap 2 (contoh: Layanan online ASN, live chat, survei IKM, integrasi bot).
  * **Sprint 4:** Pengerjaan modul tahap 3 (contoh: Aplikasi mobile Flutter, push notifikasi FCM, deployment batch runner, dan pengujian UAT).
  * *Setiap Sprint wajib menyertakan diagram pendukung yang dirender dan tangkapan layar fitur.*
* **4.4 Sprint Review:** Ulasan keberhasilan produk dan demonstrasi di hadapan pembimbing lapangan untuk tiap Sprint.
* **4.5 Sprint Retrospective:** Evaluasi kendala yang dihadapi tim dan tindakan perbaikan (*action items*) pada iterasi berikutnya.
* **4.6 User Acceptance Testing (UAT):** Pengujian penerimaan pengguna dengan tabel skenario lengkap (minimal 20+ skenario pengujian), skor skala Likert 1–5, rumus rata-rata skor, dan persentase kepuasan.

### F. BAB V: PENUTUP
* **5.1 Kesimpulan:** Poin-poin kesimpulan menjawab rumusan masalah dan tujuan kerja praktik.
* **5.2 Saran:** Rekomendasi teknis yang konstruktif untuk pengembangan sistem di masa depan.

### G. DAFTAR PUSTAKA
* Ditulis menggunakan standar **APA Style 7th Edition**, disusun urut abjad (*alphabetical*), dan menggunakan format indentasi gantung (*hanging indent* 1.27 cm).

---

## 8. STRUKTUR LAMPIRAN WAJIB (LAMPIRAN 1 s.d. 8)

Laporan Kerja Praktik **WAJIB MEMILIKI 8 LAMPIRAN LENGKAP**:

1. **LAMPIRAN 1: SERTIFIKAT KELULUSAN**  
   Halaman placeholder pemuatan sertifikat resmi penyelesaian KP.
2. **LAMPIRAN 2: SURAT PENERIMAAN INSTANSI**  
   Surat resmi bertandatangan Kepala Instansi (dilengkapi Kop Surat Resmi Pemerintah Kabupaten Banjarnegara, nomor surat kedinasan, tabel identitas mahasiswa, dan stempel instansi).
3. **LAMPIRAN 3: LEMBAR PENILAIAN PEMBIMBING LAPANGAN**  
   Format FS-KP15 Fakultas Teknik Unsoed yang memuat **6 Komponen Penilaian**:
   1. Kesesuaian dengan Rencana Kerja (Skor 96)
   2. Kehadiran di Lokasi Kerja Praktik (Skor 100)
   3. Kedisiplinan Sikap, Etika, dan Tingkah Laku (Skor 95)
   4. Keaktifan dan Kreativitas (Skor 98)
   5. Kecermatan dan Kualitas Sistem/Antarmuka (Skor 96)
   6. Tanggung Jawab dan Kerjasama Tim (Skor 96)  
   *Rata-rata Nilai: 96.83 (Huruf Mutu: A - SANGAT BAIK).*
4. **LAMPIRAN 4: LEMBAR PRESENSI KERJA PRAKTIK**  
   Tabel presensi **24 Hari Kerja Lengkap** (Senin–Jumat, jam masuk 07:30, jam keluar 16:00, uraian kegiatan harian yang relevan, dan tanda centang paraf `✓`).
5. **LAMPIRAN 5: LOGBOOK KERJA PRAKTIK**  
   Tabel logbook **24 Hari Kerja Lengkap** yang memuat kolom: *No*, *Tanggal*, *Uraian Detail Pekerjaan Teknis*, dan *Bukti Dokumentasi*.
6. **LAMPIRAN 6: DOKUMENTASI USER ACCEPTANCE TESTING (UAT)**  
   Lembar instrumen pengujian pengguna lengkap dengan nama penguji, tabel skenario uji, hasil yang diharapkan, hasil pengamatan ("Sesuai Ekspektasi"), dan skor nilai.
7. **LAMPIRAN 7: DOKUMENTASI KEGIATAN**  
   Daftar 6 dokumentasi foto kegiatan kerja praktik mahasiswa di kantor instansi.
8. **LAMPIRAN 8: CURRICULUM VITAE (CV)**  
   Biodata lengkap mahasiswa: Nama, Alamat, Kontak/WhatsApp, Email, GitHub, Ringkasan Profil Profesional, Riwayat Pendidikan & IPK, Pengalaman Kerja/Proyek KP, dan Daftar Keahlian Teknis.

---

## 9. CARA MENJALANKAN GENERATOR DOKUMEN OTOMATIS

Folder ini telah dilengkapi skrip generator Python otomatis di:  
`AI Skill KP generator/scripts/kp_docx_generator.py`

### Perintah Eksekusi Otomatis:
```bash
python "AI Skill KP generator/scripts/kp_docx_generator.py" \
    --input "path/to/laporan.md" \
    --output "path/to/Laporan_KP_Mahasiswa.docx" \
    --author "NAMA MAHASISWA" \
    --nim "H1D024XXX" \
    --title "JUDUL LAPORAN KERJA PRAKTIK..."
```

Skrip ini akan secara otomatis:
1. Membaca file markdown sumber.
2. Mengunduh dan me-render semua diagram Mermaid ke gambar PNG via API.
3. Mengatur layout kertas A4 dan margin standar 4-3-3-3 cm.
4. Menerapkan penomoran halaman dinamis (*Section 1: Cover tanpa nomor*, *Section 2: Romawi kecil i, ii, iii...*, *Section 3: Angka biasa 1, 2, 3...*).
5. Membersihkan baris pemisah separator `---` pada tabel.
6. Menyematkan Logo Unsoed dan diagram-diagram beresolusi tinggi.
7. Menghasilkan dokumen Microsoft Word (`.docx`) yang 100% siap cetak dan bebas error.
