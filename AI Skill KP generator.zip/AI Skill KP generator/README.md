# AI SKILL: KERJA PRAKTIK (KP) REPORT GENERATOR
### Standard Panduan & Generator Laporan Kerja Praktik Universitas Jenderal Soedirman (Jurusan Informatika)

Modul ini dirancang khusus agar AI Agent dapat memahami secara utuh standar tata letak, struktur bab, tipografi, dan aturan pembuatan laporan Kerja Praktik (KP) yang 100% identik dengan acuan resmi:
1. `assets/Laporan_Kerja_Praktik_BKPSDM_Iqsan_Azhar_Nuryadi.pdf` (Berkas PDF Asli Hasil Jadi)
2. `assets/dokumen.md` (Berkas Dokumen Scope & WBS)
3. `assets/laporan_kerja_praktik_bkpsdm.md` (Berkas Markdown Asli Sumber Teks Lengkap)

---

## 🤖 Persyaratan Model AI (Model Requirement)

> **⚠️ PERHATIAN PENTING:**  
> Modul skill ini **WAJIB menggunakan model `Gemini 4.7 Flash`** (atau varian Gemini Flash yang kompatibel). Seluruh pengujian tata letak, logika pemecahan bab, struktur WBS, dan rendering dokumen laporan ini telah divalidasi dan diuji khusus pada model **Gemini 4.7 Flash**. Penggunaan model lain belum teruji dan berpotensi menimbulkan ketidaksesuaian format.

---

## 📁 Struktur Berkas Lengkap

```text
d:\lokal bkpsdm\AI Skill KP generator\
├── agent.md                    # Panduan sistematis, aturan ketat (strict rules), & instruksi bagi AI Agent
├── README.md                   # Dokumen panduan utama penggunaan modul skill
├── assets/
│   ├── logo_unsoed.png         # Logo resmi Universitas Jenderal Soedirman resolusi tinggi
│   ├── Laporan_Kerja_Praktik_BKPSDM_Iqsan_Azhar_Nuryadi.pdf # Berkas PDF asli hasil jadi laporan KP
│   ├── dokumen.md              # Berkas dokumen scope proyek, WBS, dan jadwal kerja praktik
│   └── laporan_kerja_praktik_bkpsdm.md # Berkas Markdown lengkap sumber teks laporan
├── scripts/
│   ├── kp_docx_generator.py    # Mesin Python otomasi rendering Markdown -> Microsoft Word (.docx)
│   └── README.md               # Panduan teknis penggunaan skrip generator Python
└── templates/
    └── template_structure.md   # Kerangka dasar bab & lampiran 1 s.d. 8 siap pakai
```

---

## 🚀 Cara Menggunakan Modul Ini

### Cara 1: Menginstruksikan AI Melalui Prompt Chat
Cukup berikan perintah kepada asisten AI Anda di jendela chat:

> *"Tolong buatkan laporan Kerja Praktik untuk mahasiswa bernama **[Nama Mahasiswa]**, NIM **[NIM]**, topik/peran sebagai **[Topik/Peran]**, dengan membaca dan mengikuti panduan di `AI Skill KP generator/agent.md`."*

AI akan secara otomatis:
1. Membaca berkas `agent.md` dan mempelajari contoh nyata di folder `assets/`.
2. Menghasilkan draf laporan lengkap dari Halaman Judul, Pernyataan, Pengesahan, BAB I s.d. BAB V, Daftar Pustaka (APA 7th), serta Lampiran 1 s.d. 8.
3. Menjalankan skrip `scripts/kp_docx_generator.py` untuk mengompilasi draf laporan menjadi dokumen Word (`.docx`) siap cetak.

---

### Cara 2: Menjalankan Generator DOCX Secara Mandiri
Jika Anda sudah memiliki draf laporan dalam format Markdown (`.md`), Anda dapat langsung mengonversinya ke dokumen Word `.docx` menggunakan terminal:

```bash
python "AI Skill KP generator/scripts/kp_docx_generator.py" \
    --input "path/to/laporan.md" \
    --output "path/to/Laporan_KP.docx" \
    --author "NAMA MAHASISWA" \
    --nim "H1D024XXX" \
    --title "JUDUL LENGKAP LAPORAN KERJA PRAKTIK..."
```

---

## 📐 Standar Format Wajib yang Diterapkan

| Komponen Dokumen | Standar Format yang Diterapkan |
|---|---|
| **Kertas & Margin** | A4 (21.0 × 29.7 cm), Margin: Kiri **4.0 cm**, Atas **3.0 cm**, Kanan **3.0 cm**, Bawah **3.0 cm**. |
| **Tipografi** | *Times New Roman*, 12 pt untuk teks isi, 1.5 spasi baris, 1 cm *first-line indent*, teks rata kiri-kanan (*Justified*). |
| **Penomoran Halaman** | **Cover:** Tanpa nomor.<br>**Bagian Awal:** Romawi kecil (`i, ii, iii...`) di kanan bawah.<br>**Bagian Isi:** Angka Arab (`1, 2, 3...`) di kanan bawah. |
| **Tabel (21 Tabel)** | Bebas baris separator `---`, latar header abu-abu halus (`#F1F5F9`), teks tebal, *cantSplit*, dan lembar pengesahan *borderless*. |
| **Diagram Sistem** | Seluruh diagram (Arsitektur, Use Case, Class, ERD, Flowchart, Sequence) wajib di-render menjadi gambar PNG berkualitas tinggi. |
| **Daftar Isi & Tabel** | Diformat dengan Tab Stop ber-leader titik-titik (`.........`) rata kanan rapi pada margin 14.0 cm. |
| **Lampiran Lengkap** | Wajib memuat Lampiran 1 s.d. 8 (Sertifikat, Surat Instansi, Penilaian Nilai A, Presensi 24 hari, Logbook, UAT, Foto, dan CV). |

## 💡 Catatan Penting untuk Pengguna (User Notes & Best Practices)

1. **Tangkapan Layar (*Screenshot* / SS Website & Aplikasi):**
   * Anda dapat meminta AI untuk menjalankan aplikasi/server lokal dan bertindak sebagai subagent browser untuk mengambil tangkapan layar antarmuka secara otomatis.
   * Namun, **secara *default* AI tidak mengambil screenshot otomatis** karena proses tersebut memakan banyak kuota token percakapan (*context window*). AI akan menyiapkan tempat caption gambar rapi yang dapat Anda tempeli screenshot asli secara manual, atau Anda dapat memerintahkan AI mengambilnya secara spesifik jika dibutuhkan.
2. **Lampiran 1 s.d. 8 Adalah Draf Contoh:**
   * Lampiran yang dibuat oleh AI (seperti Surat Penerimaan Instansi, Lembar Penilaian Nilai A 96.83, Presensi, dan Logbook) adalah **draf acuan format yang terstruktur**.
   * Anda wajib mengganti atau melengkapinya dengan dokumen fisik asli (surat resmi bertanda tangan basah dan berstempel instansi BKPSDM serta scan sertifikat Anda).
3. **Diagram Sistem (Mermaid -> Gambar PNG Otomatis):**
   * AI akan menulis spesifikasi diagram dalam format sintaks Mermaid (Arsitektur, Use Case, Class Diagram, ERD, Flowchart, dan Sequence Diagram).
   * Skrip generator (`kp_docx_generator.py`) secara otomatis me-render kode Mermaid tersebut menjadi gambar visual PNG resolusi tinggi dan menyematkannya di dalam dokumen Word.
4. **Penyesuaian Nomor Halaman pada Daftar Isi:**
   * Nomor halaman pada teks Daftar Isi, Daftar Gambar, dan Daftar Tabel pada dokumen draf awal adalah estimasi.
   * Anda dapat menyesuaikannya secara manual saat pengeditan akhir di Microsoft Word sesuai halaman riil, atau menggunakan fitur **Update Field (`F9`)** pada tabel daftar isi Word.
5. **Pengaturan Cetak Kertas A4:**
   * Saat hendak mencetak (*print* / cetak jilid), pastikan opsi ukuran kertas pada printer diatur ke **A4** (bukan Letter) agar batas margin 4-3-3-3 cm tetap presisi dan tidak terpotong saat proses penjilidan.

---

## 👁️ Cara Cepat Melihat Hasil DOCX di VS Code

Anda dapat mempratinjau file dokumen Word hasil kompilasi langsung di dalam VS Code menggunakan ekstensi **DocxViewer**:
1. Buka panel Explorer di VS Code.
2. Klik kanan pada file `.docx` yang dihasilkan.
3. Pilih **`DOCX Viewer: Open File`**.
4. Dokumen akan terbuka langsung di tab editor tanpa mengunci file (*no file lock*).
