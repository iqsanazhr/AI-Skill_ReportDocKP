# PANDUAN PENGGUNAAN: `kp_docx_generator.py`
### Skrip Otomasi Pengonversi Laporan Kerja Praktik (Markdown -> Word .docx)

Skrip `kp_docx_generator.py` adalah mesin generator dokumen Microsoft Word (`.docx`) mandiri yang dirancang khusus untuk memenuhi standar format penulisan Kerja Praktik (KP) Jurusan Informatika, Fakultas Teknik, Universitas Jenderal Soedirman.

---

## ⚙️ Persyaratan Sistem & Dependensi

* **Model AI Pengembang:** **Gemini 4.7 Flash** *(Seluruh pembuatan berkas markdown laporan dan struktur tabel divalidasi dengan model ini)*.
* **Environment:** Python 3.8+
* **Pustaka Python:** `python-docx`

```bash
pip install python-docx
```

---

## 🚀 Cara Menjalankan Skrip

Skrip dapat dijalankan langsung melalui terminal / command prompt dengan perintah:

### Sintaks Dasar:
```bash
python kp_docx_generator.py --input <path_file_markdown> --output <path_file_docx> [opsi_tambahan]
```

### Contoh Perintah Lengkap:
```bash
python "AI Skill KP generator/scripts/kp_docx_generator.py" \
    --input "d:/lokal bkpsdm/laporan_kerja_praktik_bkpsdm.md" \
    --output "d:/lokal bkpsdm/Laporan_KP_Iqsan.docx" \
    --author "IQSAN AZHAR NURYADI" \
    --nim "H1D024009" \
    --title "RANCANG BANGUN SISTEM BACKEND, RESTFUL API GATEWAY, DAN INTEGRASI MULTI-SERVICE PELAYANAN..."
```

---

## 📋 Daftar Argumen CLI (*Command-Line Arguments*)

| Parameter | Singkatan | Wajib? | Keterangan & Nilai Default |
|---|:---:|:---:|---|
| `--input` | `-i` | **Ya** | Path ke file sumber laporan bertipe markdown (`.md`). |
| `--output` | `-o` | **Ya** | Path tujuan penyimpanan file dokumen Word (`.docx`). |
| `--author` | `-a` | Tidak | Nama lengkap penyusun (jika tidak diisi, otomatis mendeteksi dari teks markdown). |
| `--nim` | `-n` | Tidak | NIM mahasiswa (jika tidak diisi, otomatis mendeteksi dari teks markdown). |
| `--title` | `-t` | Tidak | Judul lengkap laporan (jika tidak diisi, otomatis mengambil `# Heading 1` pertama). |
| `--logo` | `-l` | Tidak | Path ke file logo Unsoed PNG (default: `../assets/logo_unsoed.png`). |
| `--diagrams`| `-d` | Tidak | Folder penyimpanan gambar diagram PNG yang telah dirender. |

---

## ✨ Fitur Unggulan & Standar Format yang Diterapkan

1. **Format Kertas & Margin 4-3-3-3:**
   * Ukuran Kertas: A4 (21.0 × 29.7 cm).
   * Margin Kiri: **4.0 cm** (standar jilid tebal).
   * Margin Atas, Kanan, Bawah: masing-masing **3.0 cm**.
2. **Tipografi & Paragraf Akademik:**
   * Font baku: *Times New Roman*, 12 pt, 1.5 spasi baris (*Line Spacing*), *Space After* 6 pt.
   * Perataan: *Justify* (rata kiri-kanan).
   * Indentasi baris pertama (*First-Line Indent*): **1.0 cm**.
3. **Penomoran Halaman Otomatis (*Multi-Section Numbering*):**
   * **Cover Depan:** Bersih tanpa nomor halaman.
   * **Bagian Awal (*Pernyataan s.d. Daftar Tabel*):** Format angka Romawi kecil (**`i, ii, iii...`**) di pojok kanan bawah.
   * **Bagian Isi (*BAB I s.d. Lampiran 8*):** Format angka Arab biasa (**`1, 2, 3...`**) dimulai kembali dari `1` di pojok kanan bawah.
4. **Pembersihan Tabel Otomatis:**
   * Mendeteksi dan membuang baris pemisah markdown seperti `|:---:|---|---|` secara otomatis, sehingga tidak ada teks `---` yang muncul di dalam tabel Word.
   * Memberikan *header shading* abu-abu halus (`#F1F5F9`), teks tebal, dan `<w:tblHeader/>` agar header berulang di halaman baru.
   * Menambahkan `<w:cantSplit/>` agar baris tabel tidak terpotong canggung saat pergantian halaman.
   * Tabel tanda tangan lembar pengesahan otomatis dibuat tanpa garis (*borderless*).
5. **Daftar Isi, Gambar, dan Tabel dengan Tab Leader Titik-Titik:**
   * Menerapkan tab stop native Word dengan *dot leader* (`.........`) yang rata kanan rapi pada margin 14.0 cm.
6. **Penanganan Otomatis File Locked (*Permission Fallback*):**
   * Jika file output sedang dibuka di aplikasi Microsoft Word oleh pengguna, skrip tidak akan crash, melainkan otomatis menyimpan ke file alternatif (contoh: `_New.docx`).

---

## 👁️ Tips Mempratinjau Dokumen di VS Code

Untuk melihat hasil kompilasi dokumen Word tanpa harus membuka Microsoft Word desktop (yang dapat mengunci file):
1. Buka file `.docx` di VS Code Explorer.
2. Klik kanan lalu pilih **`DOCX Viewer: Open File`**.
3. Dokumen dapat dipratinjau langsung di tab editor VS Code tanpa risiko *file lock*.
